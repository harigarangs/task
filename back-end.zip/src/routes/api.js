const express = require("express");
const router = express.Router();
const { userController } = require("../controllers");
const apiAuth = require("../middlewares/apiAuth");

//= ===============================
// API routes
//= ===============================

//** user endpoint */
router.get("/singleUser/:userId", apiAuth, userController.singleUserData);
router.put("/updateUser/:userId", apiAuth, userController.updateUserData);

module.exports = router;
