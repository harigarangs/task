module.exports = Object.freeze({
    USER_NOT_FOUND: "User is not found",
    NOT_ADMIN : 'You don\'t have admin access'
})