const keys = {
    USER_STATUS_ACTIVE: 'active',
    USER_STATUS_INACTIVE: 'inActive'
}

module.exports = { keys }