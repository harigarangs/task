
const tokenTypes = {
    ACCESS: 'access',
    REFERSH: 'refresh',
    RESET_PASSWORD: 'resetPassword'
}

module.exports = { tokenTypes }
