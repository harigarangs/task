const express = require("express");
const bodyParser = require("body-parser");
const dotenv = require("dotenv");
const cors = require("cors");
const routes = require("./src/routes/index");
const path = require("path");
const passport = require("passport");
const http = require("http");
const { jwtStrategy } = require("./src/config/passport");
const socketIo = require("socket.io");
require("./src/config/db_connection");
dotenv.config({ path: path.join(__dirname, "./.env") });

const app = express();
const server = http.createServer(app);
const io = require("socket.io")(server);
// parse json request body
// app.use(express.json());

// enable cors
app.use(cors());
app.options("*", cors());

// jwt authentication
app.use(passport.initialize());
passport.use("jwt", jwtStrategy);

// parse urlencoded request body
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static("public"));

// v3 app routes
app.use("/v3", routes);

// socketHelper.SocketInit(io);

io.on("connection", (socket) => {
  console.log("A user connected");

  socket.on("disconnect", () => {
    console.log("User disconnected");
  });

  socket.on("message", (data) => {
    console.log("Message received:", data);
    io.emit("message", data); // Broadcasting message to all clients
  });
});

// send back a 404 error for any unknown api request
app.use((req, res, next) => {
  next(new Error("Not found"));
});

module.exports = app;
