import Authorized from '../Auth/reducer'
export const reducers = { Authorized }