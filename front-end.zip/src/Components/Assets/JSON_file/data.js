
export const Data = [

   {
       id:1,
       Catagory_Name:"Boots"
   },
   {
       id:2,
       Catagory_Name:"FlipFlop"
   },
   {
        id:3,
        Catagory_Name:"Floaters"
   },
   {
       id:4,
       Catagory_Name:"Formal",
       
    
    },
    {
        id:5,
        Catagory_Name:"Flats"
    },
    {
        id:6,
        Catagory_Name:"Heels"
    },
    {
        id:7,
        Catagory_Name:"Sports",
        Sub_Catagory:[{
            Sub_id:1,
            Sub_Catagory_Name: "Kids",
        },{
            Sub_id:2,
            Sub_Catagory_Name: "Womens",
        },{
            Sub_id:3,
            Sub_Catagory_Name: "Mens",
        }]
    },
    {
        id:8,
        Catagory_Name:"Sandals"
    },
    {
        id:9,
        Catagory_Name:"School"
    },
    {
        id:10,
        Catagory_Name:"Casual_Shoes"
    }
];
