
const Detail = [

    {
        id:1,
        FirstName: "Vimal",
        LastName: "Raj",
        Email: "vimal@gmail.com",
        Password:"Vim@l1",
        PasswordConfirm: "Vim@l1"
    },
    {
        id:2,
        FirstName: "Vimal",
        LastName: "Raj",
        Email: "vimalRaj@gmail.com",
        Password:"Vim@l1",
        PasswordConfirm: "Vim@l1"
    }
    
 ];
 export default Detail
 