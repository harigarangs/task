
import img_1 from "../Products/Boots/Flipflop.jpg";
import img_2 from "../Products/Boots/Floaters.jpg";
import img_3 from "../Products/Boots/Formal.jpg";
import img_4 from "../Products/Boots/Flats.jpg";
import img_5 from "../Products/Boots/Heels.jpg";
import img_6 from "../Products/Boots/Sports.jpg";
import img_7 from "../Products/Boots/Sandals.jpg";
import img_8 from "../Products/Boots/product_3.jpeg";
import img_9 from "../Products/Boots/shoes_3.jpeg";
import img_10 from "../Products/Boots/School.jpg";
import img_11 from "../Products/Boots/shoes_3.jpeg";
import img_12 from "../Products/Boots/shoes_3.jpeg";


 const Product = [
    {
        id:1,
        title:"FlipFlop",
        product_img:img_1,
        price:100
    }, {
        id:2,
        title:"Floters",
        product_img:img_2,
        price:250
    },  {
        id:3,
        title:"Formal",
        product_img:img_3,
        price:500
    }, {
        id:4,
        title:"Floters",
        product_img:img_4,
        price:200
    }, {
        id:5,
        title:"Heels",
        product_img:img_5,
        price:600
    }, {
        id:6,
        title:"Sports",
        product_img:img_6,
        price:550
    },  {
        id:7,
        title:"Sandals",
        product_img:img_7,
        price:450
    }, {
        id:8,
        title:"Sports Shoes",
        product_img:img_8,
        price:550
    }, {
        id:9,
        title:"Casual Shoes",
        product_img:img_9,
        price:650
    },{
        id:10,
        title:"Casual shirt",
        product_img:img_10,
        price:350
    },
 ];
 export default Product;